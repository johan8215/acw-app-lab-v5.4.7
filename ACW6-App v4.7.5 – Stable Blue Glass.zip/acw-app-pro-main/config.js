// ============================================================
// ⚙️ ACW-App Config — v4.6.9 Stable Blue Glass Edition
// ============================================================

const CONFIG = {
  BASE_URL: "https://script.google.com/macros/s/AKfycbwgwpnpeB9ZUxn241xITDlsTNSOdiDqNqh0fWpfX7QCiAPGjEWwTfnDD4si88fIEI7O/exec",
  VERSION: "v4.6.9 — Stable Blue Glass Edition"
};

console.log(`✅ ACW-App connected → ${CONFIG.VERSION}`);
